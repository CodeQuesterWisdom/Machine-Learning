import sys

class MyPlayer():
    def __init__(self):
        self.type = 'my'

    def get_input(self, go, piece_type):
        '''
        Get one input.

        :param go: Go instance.
        :param piece_type: 1('X') or 2('O').
        :return: (row, column) coordinate of input.
        '''   
        pass
        # return i,j